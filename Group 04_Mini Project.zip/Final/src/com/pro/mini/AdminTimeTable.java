/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pro.mini;

/**
 *
 * @author mohamedakthar
 */
public class AdminTimeTable extends Admin {
    
    private char Table_Id;
    private char Start_Time;
    private char End_Time;
    
    
  private void Create_TimeTable(){}
  private void Delete_TimeTable(){}
    
}
