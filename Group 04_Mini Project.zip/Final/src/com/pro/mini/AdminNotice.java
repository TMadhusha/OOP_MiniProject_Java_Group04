/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pro.mini;

/**
 *
 * @author mohamedakthar
 */
public class AdminNotice extends User{
    
    private int Notice_Id;
    private int Date;
    private int Subject;
    
    
    private void CreateNotice(){}
    private void DeleteNotice(){}
    
    
}
