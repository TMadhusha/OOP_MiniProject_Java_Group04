/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pro.mini;

/**
 *
 * @author mohamedakthar
 */
public class User implements Person {
    public int User_Id;
    public char Fname;
    public char Lname;
    public char Address;
    public char DOB;
    public char Gender;
    public char Email;
    public int PhoneNum;
    
    @Override
    public void Log(){
    
      
    
    }
    @Override
    public void View(){}
    
    
    
}
