/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pro.mini;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mohamedakthar
 */
public class DbConnect {
    
    private void Registrer(){
    
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.print("Issue in the Class-ForName ");
                   
        }
    }
    public Connection connect(){

    Registrer();
    
    Connection con = null;
        try {
            // con=DriveManager.getconnection("jdbc:mysql://localhost:3306/tecmis","root","mhda21234");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/tecmis_DB","root","");
        } catch (SQLException ex) {
            Logger.getLogger(DbConnect.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    return con;

}
    
}