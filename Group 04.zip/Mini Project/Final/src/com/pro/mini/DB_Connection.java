/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pro.mini;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DB_Connection {
    //Restric cleation object in onother class make constructor private 
    private DB_Connection() {}
    
    //create object type private static
   private static final DB_Connection dbConnector = new DB_Connection();
   
   //Return object
   public static DB_Connection getObject(){  
       return dbConnector;
   }
   public static Connection getConnection(){
       Connection conn=null;
       String url="jdbc:mysql://localhost:3306/tecmis_DB";
       String username="root";
       String Password="";
       
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn=DriverManager.getConnection(url,username,Password);
        }  catch (ClassNotFoundException | SQLException ex) {
               Logger.getLogger(DB_Connection.class.getName()).log(Level.SEVERE, null, ex);
           }

       return conn;
   }
}
    
